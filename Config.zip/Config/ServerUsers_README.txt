The ServerUsers.txt file stores all the players that have ever been on a server. Altering this file directly should not generally be required. 

The main reason to edit this file would be to increase a players user group. The number directly after the long Steam ID. When in game players can promote other player to any rank that is lower than their own. To set a rank in-game. 

/setrank userName indexOfRank
Or
/setrank userName rankName


Example user:  76561198004636696,3,false,false,Jayty