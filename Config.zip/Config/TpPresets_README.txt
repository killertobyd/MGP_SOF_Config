The TpPresets.json holds a series of teleportation locations. To edit, add or remove these presets the following commands can be used in game.

/tppreset add nameOfPreset //This adds a tp location a the place where your player is currently located.
/tppreset update nameOfPreset //This will edit an existing preset to the location the player is currently located.
/tppreset remove nameOfPreset //Deletes preset of name.
/tppreset clear //Clears all tp presets.

To use preset locations enter the commands.

/tp me nameOfPreset //Tp's yourself to location.
/tp userName nameOfPreset //Tp's another player to location.

NOTE: Requires teleportation permissions to edit/use.